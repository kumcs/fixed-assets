COMMENT ON SCHEMA asset IS '  This file is part of the Fixed Asset Package for xTuple ERP, and is Copyright (c) 2012-2015 by Pentuple Ltd. New Zealand.  It is licensed to you under the CPAL. By using this software, you agree to be bound by the terms of the EULA.';

GRANT ALL ON SCHEMA asset TO xtrole;
