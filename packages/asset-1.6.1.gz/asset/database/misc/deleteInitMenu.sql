/* xtDesktop increased its initmenu grade so FA has to be higher 
*/
delete from asset.pkgscript where script_name = 'initMenu';
