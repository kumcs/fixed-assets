<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>asset</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetDisp</name>
    <message>
        <source>Asset Disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_disp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disp_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disp_descr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetDispList</name>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Dispositions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Dispositions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetList</name>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retire...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action will permanently delete the asset.
 Do you wish to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions Exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions exist for this asset.  It cannot be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List of Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Retired Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C, Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q, Return, Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetType</name>
    <message>
        <source>Asset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depreciation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depreciation Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>depn_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depreciation %:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_depnperc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>per annum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Determination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed Asset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_gl1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_gl2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_gl3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_gl4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>assettype_gl5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accum. Depreciation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depreciation Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain/Loss on Sale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scrap Expense:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetTypeList</name>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Types:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAssetManagement</name>
    <message>
        <source>Asset Mgmt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>order_add_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.new_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ImgRightArrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>order_zoom_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.listFixedAssets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>spreadsheet_zoom_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.asset_types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>trash_ok_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Dispositions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.asset_disp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Finance / Depreciation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inventory_add_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.purchase_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>collection_account_write_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depreciate Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.depreciate_assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>accounting_info_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unposted Depn Transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.post_transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sell / Scrap Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.sell_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance Tasks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.maintenance_task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance Plans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.maintenance_plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance Classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.maintenance_class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>industry_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.maintenance_schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>industry_ok_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fa.maintenance_orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspAssetLocation</name>
    <message>
        <source>Fixed Assets by Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retire...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Asset Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must select an Asset first</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspAssets</name>
    <message>
        <source>Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Retired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retire...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action will permanently delete the asset.
 Do you wish to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions Exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions exist for this asset.  It cannot be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fixedAsset</name>
    <message>
        <source>Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Asset Types have been maintained. Please set up the Asset Types before creating Fixed Assets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sell Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Asset has sub-assets assigned.  Do you want to update the sub-asset locations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub-Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vw_fixed_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code/Tag:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_type_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_status_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print on Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent Asset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brand:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Model:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_purch_place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_purch_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Install Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_install_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_purch_price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Residual Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_residual_value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Life:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_life</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Place:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>External Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CRM Account the Asset is located at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The physical address the Asset is located</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_crmacct_id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_line1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_line2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_line3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_city</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_postalcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr_country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_last_service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Characteristics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset Retire Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_retire_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disposition Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account / Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warranty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_warranty_exp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warranty Expiry:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>asset_warranty_mth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Months</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By Location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Types...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dispositions...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
