<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>asset</name>
    <message>
        <location filename="../scripts/asset.js" line="14"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetDisp</name>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="27"/>
        <source>Asset Disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="39"/>
        <source>asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="42"/>
        <source>asset_disp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="56"/>
        <source>Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="66"/>
        <source>disp_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="79"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="89"/>
        <source>disp_descr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="100"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="103"/>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="110"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDisp.ui" line="113"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetDispList</name>
    <message>
        <location filename="../scripts/assetDispList.js" line="38"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetDispList.js" line="41"/>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="27"/>
        <source>Asset Disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="37"/>
        <source>Asset Dispositions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="60"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="67"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="77"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetDispList.ui" line="87"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetList</name>
    <message>
        <location filename="../scripts/assetList.js" line="56"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="61"/>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="67"/>
        <source>Retire...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="73"/>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="78"/>
        <source>Asset Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="172"/>
        <source>Delete Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="172"/>
        <source>This action will permanently delete the asset.
 Do you wish to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="186"/>
        <source>Transactions Exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetList.js" line="186"/>
        <source>Transactions exist for this asset.  It cannot be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="27"/>
        <source>List of Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="37"/>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="50"/>
        <source>All Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="57"/>
        <source>Asset Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="66"/>
        <source>Show Retired Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="112"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="115"/>
        <source>Ctrl+C, Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="122"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="125"/>
        <source>Ctrl+Q, Return, Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="132"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="135"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="166"/>
        <source>Results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="196"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="199"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="209"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="212"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="222"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetList.ui" line="225"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetType</name>
    <message>
        <location filename="../uiforms/assetType.ui" line="27"/>
        <source>Asset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="43"/>
        <source>Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="56"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="72"/>
        <source>assettype_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="84"/>
        <source>assettype_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="123"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="130"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="154"/>
        <source>Depreciation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="168"/>
        <source>Depreciation Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="192"/>
        <source>depn_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="226"/>
        <source>Depreciation %:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="244"/>
        <source>assettype_depnperc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="251"/>
        <source>per annum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="278"/>
        <source>Account Determination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="288"/>
        <source>Fixed Asset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="298"/>
        <source>assettype_gl1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="308"/>
        <source>assettype_gl2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="318"/>
        <source>assettype_gl3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="328"/>
        <source>assettype_gl4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="338"/>
        <source>assettype_gl5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="345"/>
        <source>Accum. Depreciation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="352"/>
        <source>Depreciation Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="359"/>
        <source>Gain/Loss on Sale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetType.ui" line="366"/>
        <source>Scrap Expense:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>assetTypeList</name>
    <message>
        <location filename="../scripts/assetTypeList.js" line="42"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/assetTypeList.js" line="45"/>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="27"/>
        <source>Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="35"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="38"/>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="45"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="48"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="55"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="58"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="68"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="71"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="81"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="84"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="110"/>
        <source>Select:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/assetTypeList.ui" line="125"/>
        <source>Asset Types:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAssetManagement</name>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="14"/>
        <source>Asset Mgmt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="28"/>
        <source>Asset Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="37"/>
        <source>Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="43"/>
        <source>order_add_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="46"/>
        <source>New Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="49"/>
        <source>fa.new_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="71"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="221"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="271"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="321"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="410"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="460"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="510"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="560"/>
        <source>ImgRightArrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="93"/>
        <source>order_zoom_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="96"/>
        <source>List Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="99"/>
        <source>fa.list_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="122"/>
        <source>Asset Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="128"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="382"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="432"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="482"/>
        <source>spreadsheet_zoom_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="131"/>
        <source>Asset Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="134"/>
        <source>fa.asset_types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="154"/>
        <location filename="../uiforms/desktopAssetManagement.ui" line="343"/>
        <source>trash_ok_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="157"/>
        <source>Asset Dispositions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="160"/>
        <source>fa.asset_disp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="187"/>
        <source>Asset Finance / Depreciation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="193"/>
        <source>inventory_add_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="196"/>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="199"/>
        <source>fa.purchase_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="243"/>
        <source>collection_account_write_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="246"/>
        <source>Depreciate Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="249"/>
        <source>fa.depreciate_assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="293"/>
        <source>accounting_info_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="296"/>
        <source>Unposted Depn Transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="299"/>
        <source>fa.post_transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="346"/>
        <source>Sell / Scrap Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="349"/>
        <source>fa.sell_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="376"/>
        <source>Asset Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="385"/>
        <source>Maintenance Tasks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="388"/>
        <source>fa.maintenance_task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="435"/>
        <source>Maintenance Plans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="438"/>
        <source>fa.maintenance_plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="485"/>
        <source>Maintenance Classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="488"/>
        <source>fa.maintenance_class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="532"/>
        <source>industry_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="535"/>
        <source>Planned Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="538"/>
        <source>fa.maintenance_schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="582"/>
        <source>industry_ok_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="585"/>
        <source>Maintenance Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAssetManagement.ui" line="588"/>
        <source>fa.maintenance_orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspAssetLocation</name>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="4"/>
        <source>Fixed Assets by Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="5"/>
        <source>Asset Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="32"/>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="33"/>
        <source>Asset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="34"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="35"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="36"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="48"/>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="52"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="56"/>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="60"/>
        <source>Retire...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="64"/>
        <source>Print Asset Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="85"/>
        <location filename="../scripts/dspAssetLocation.js" line="111"/>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspAssetLocation.js" line="85"/>
        <location filename="../scripts/dspAssetLocation.js" line="111"/>
        <source>You must select an Asset first</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fixedAsset</name>
    <message>
        <location filename="../scripts/fixedAsset.js" line="242"/>
        <source>Sell Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/fixedAsset.js" line="330"/>
        <source>This Asset has sub-assets assigned.  Do you want to update the sub-asset locations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/fixedAsset.js" line="331"/>
        <source>Sub-Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="21"/>
        <source>Fixed Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="27"/>
        <source>asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="30"/>
        <source>vw_fixed_asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="45"/>
        <source>Code/Tag:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="52"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="68"/>
        <source>asset_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="75"/>
        <source>Asset Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="82"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="101"/>
        <source>asset_type_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="120"/>
        <source>asset_status_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="132"/>
        <source>asset_code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="154"/>
        <source>Print on Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="183"/>
        <source>Parent Asset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="222"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="225"/>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="235"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="238"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="262"/>
        <source>Asset Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="270"/>
        <source>Brand:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="308"/>
        <source>Model:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="318"/>
        <source>asset_model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="325"/>
        <source>Barcode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="335"/>
        <source>asset_barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="342"/>
        <source>Serial #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="352"/>
        <source>asset_serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="380"/>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="392"/>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="409"/>
        <source>Purch Place:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="422"/>
        <source>asset_purch_place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="429"/>
        <source>Purchase Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="445"/>
        <source>asset_purch_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="452"/>
        <source>Install Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="468"/>
        <source>asset_install_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="475"/>
        <source>Asset Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="500"/>
        <source>asset_purch_price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="507"/>
        <source>Residual Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="526"/>
        <source>asset_residual_value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="533"/>
        <source>Asset Life:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="548"/>
        <source>asset_life</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="555"/>
        <source>years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="597"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="605"/>
        <source>The CRM Account the Asset is located at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="608"/>
        <source>Internal Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="616"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="667"/>
        <source>The physical address the Asset is located</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="670"/>
        <source>External Location: Account / Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="676"/>
        <source>Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="679"/>
        <source>asset_crmacct_id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="686"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="699"/>
        <source>asset_address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="702"/>
        <source>addr_line1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="705"/>
        <source>addr_line2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="708"/>
        <source>addr_line3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="711"/>
        <source>addr_city</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="714"/>
        <source>addr_state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="717"/>
        <source>addr_postalcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="720"/>
        <source>addr_country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="746"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="755"/>
        <source>asset_comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="763"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="775"/>
        <source>Last Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="782"/>
        <source>asset_last_service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="829"/>
        <source>Asset Retire Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="839"/>
        <source>asset_retire_date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="846"/>
        <source>Disposition Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="859"/>
        <source>asset_disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="866"/>
        <source>Warranty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="879"/>
        <source>asset_warranty_exp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="886"/>
        <source>Warranty Expiry:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="904"/>
        <source>asset_warranty_mth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/fixedAsset.ui" line="911"/>
        <source>Months</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <location filename="../scripts/initMenu.js" line="6"/>
        <source>Fixed Assets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="13"/>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="14"/>
        <source>List...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="15"/>
        <source>By Location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="17"/>
        <source>Types...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="18"/>
        <source>Dispositions...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
