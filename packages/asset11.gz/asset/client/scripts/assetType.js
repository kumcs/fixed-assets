var _close = mywindow.findChild("_close");
var _save = mywindow.findChild("_save");
var _assetCode = mywindow.findChild("_assetCode");
var _assetName = mywindow.findChild("_assetName");
var _assetType = mywindow.findChild("_assetType");
var _assetDepn = mywindow.findChild("_assetDepn");
var _glFixedAsset = mywindow.findChild("_glFixedAsset");
var _glAccumDepn = mywindow.findChild("_glAccumDepn");
var _glDepnExp = mywindow.findChild("_glDepnExp");
var _glGainLoss = mywindow.findChild("_glGainLoss");
var _glScrap = mywindow.findChild("_glScrap");
var _depnperc = mywindow.findChild("_depnperc");

var _newMode = 0;
var _editMode = 1;
var _viewMode = 2;
var _assettypeid;

_close.clicked.connect(close);
_save.clicked.connect(saveAsset);

_assetDepn.populate("SELECT depn_id as id, depn_name as name from asset.asset_depn ORDER BY depn_id");

function close()
{
 mywindow.close();
}

function prepare()
{
  _assetCode.clear();
  _assetName.clear();
  _depnperc.text = '00.0';
}

function populate()
{
  _assetType.select();
  if (_assetType.mode == _editMode)
  {
   var p = new Object();
   p.assettype = _assettypeid;
   var d=toolbox.executeQuery("SELECT * FROM asset.asset_type WHERE id = <? value(\"assettype\") ?>", p);
   if (d.first())
   {
     _depnperc.localValue = d.value("assettype_depnperc");
     _glFixedAsset.setId(d.value("assettype_gl1"));
     _glAccumDepn.setId(d.value("assettype_gl2"));
     _glDepnExp.setId(d.value("assettype_gl3"));
     _glGainLoss.setId(d.value("assettype_gl4"));
     _glScrap.setId(d.value("assettype_gl5"));
   }
   _assetCode.enabled = false;
   _assetDepn.enabled = false;
   _depnperc.enabled = false;
  }
}

function set(input)
{
 if ("mode" in input)
 {
  _assetType.setMode(input.mode);
  if (input.mode == _newMode)
  {
    prepare();
  }
 }
 if ("filter" in input)
 {
   _assetType.setFilter(input.filter);
   _assettypeid = input.assettypeid;
   populate();
 } 
 return 0;
}

function saveAsset()
{

// Check required details have been entered 
  if (_assetDepn.id() == -1 || _assetCode.text == "" || _assetName.text == "" || _assetDepn.id() == -1 || _glFixedAsset.id() == -1 || _glAccumDepn.id() == -1 || _glDepnExp.id() == -1 || _glGainLoss.id() == -1 || _glScrap.id() == -1)
  {
    QMessageBox.warning(mywindow, "Missing Information", "You must enter all details before saving");
    return 0;
  }

// If Diminishing Value is selected you must select a Depreciation %
  if (_assetDepn.id() == 2 && _depnperc.toDouble() == 0)
  {
    QMessageBox.warning(mywindow, "Missing Information", "You must enter a Depreciation % with Diminishing Value.");
    return 0;
  }

  if (_assetType.mode == _newMode)
  {
   var sql = 'INSERT INTO asset.asset_type (assettype_code, assettype_name, assettype_depn, assettype_gl1, assettype_gl2, assettype_gl3, assettype_gl4, assettype_gl5, assettype_depnperc)'
     + ' VALUES(<? value("code") ?>, <? value("name") ?>,<? value("depn") ?>,<? value("gl1") ?>,<? value("gl2") ?>,<? value("gl3") ?>,<? value("gl4") ?>,<? value("gl5") ?>,<? value("depnperc") ?>)';
   var d = toolbox.executeQuery(sql, getParams());
  } else {
   var sql = 'UPDATE asset.asset_type SET assettype_name = <? value("name") ?>, assettype_gl1 =<? value("gl1") ?>, assettype_gl2 =<? value("gl2") ?>,assettype_gl3 =<? value("gl3") ?>,assettype_gl4 =<? value("gl4") ?>,assettype_gl5 =<? value("gl5") ?>'
       + ' WHERE assettype_code = <? value("code") ?>';
   var d = toolbox.executeQuery(sql, getParams());
  }

  mainwindow.sSalesOrdersUpdated(-1);
  close();
} 

function getParams()
{
 var params = new Object();
 params.code = _assetCode.text;
 params.name = _assetName.text;
 params.depn = _assetDepn.id();
 params.depnperc = _depnperc.toDouble();
 params.gl1 = _glFixedAsset.id();
 params.gl2 = _glAccumDepn.id();
 params.gl3 = _glDepnExp.id();
 params.gl4 = _glGainLoss.id();
 params.gl5 = _glScrap.id();

 return params;
}

