COMMENT ON SCHEMA asset IS '  This file is part of the Fixed Asset Package for xTuple ERP, and is Copyright (c) 2012 by Anderson.NET New Zealand.  It is licensed to you under the CPAL.   This Package is not free software.  By using this software, you agree to be bound by the terms of the EULA.';

GRANT ALL ON SCHEMA asset TO xtrole;
